to run the program simply run the command:
python3 -u wrestle.py arg1 arg2 etc

where the arguments are text files in the proper format to be read in by the program
