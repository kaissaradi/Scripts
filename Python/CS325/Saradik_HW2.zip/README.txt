to run the program simply run the command:
python3 -u badSort.py
or:
python3 -u badSortTime.py