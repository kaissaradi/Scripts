to run the program simply run the command:
python3 -u change.py
